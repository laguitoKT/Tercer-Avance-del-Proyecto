<footer>
    <p>&copy; 2024 ALL RIGHTS BY PRODord </p>
</footer>